// admin/components/charts/SearchConversionFunnel.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

const COLORS = ["#60a5fa", "#f59e0b", "#10b981"];

export default function SearchConversionFunnel({ start, end }) {
  const [funnel, setFunnel] = useState([]);

  useEffect(() => {
    const load = async () => {
      const q = `/api/analytics/search/funnel?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;
      const res = await fetchDataFromApi(q, false);
      if (res?.success) setFunnel(res.funnel || []);
    };
    if (start && end) load();
  }, [start, end]);

  const total = funnel.reduce((s, f) => s + f.value, 0) || 1;
  const data = funnel.map((f) => ({ name: f.stage, value: f.value }));

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-3">Search Conversion Funnel</h3>
      <div className="flex gap-4 items-center">
        <div style={{ width: 160, height: 160 }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={data} innerRadius={30} outerRadius={70} dataKey="value" label>
                {data.map((entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex-1">
          {data.map((d, i) => (
            <div key={i} className="flex justify-between py-1">
              <div className="flex items-center gap-2">
                <span style={{ width: 12, height: 12, background: COLORS[i % COLORS.length], display: "inline-block", borderRadius: 2 }} />
                <div>{d.name}</div>
              </div>
              <div className="font-semibold">{d.value} ({Math.round((d.value/total)*100)}%)</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
