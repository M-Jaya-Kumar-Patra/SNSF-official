"use client";
import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function MostTimeSpentPages() {
  const [data, setData] = useState([]);
  const [totalTime, setTotalTime] = useState(0);

  const fetchData = async () => {
    const res = await fetchDataFromApi(`/api/analytics/pages/timeSpent`, false);
    if (res?.success) {
      const arr = res.data.map((item) => ({
        page: item.pageName,
        time: item.totalTime, // in seconds
      }));
      setData(arr);
      setTotalTime(arr.reduce((s, x) => s + x.time, 0));
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="w-full p-4 bg-white rounded-md shadow">
      <div className="flex justify-between mb-3">
        <h3 className="font-semibold text-black">Most Time Spent Pages</h3>
        <div className="font-bold">{totalTime} sec</div>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="page" />
          <YAxis allowDecimals={false} />
          <Tooltip />
          <Bar dataKey="time" fill="#8b5cf6" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
