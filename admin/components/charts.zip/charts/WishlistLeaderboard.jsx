// admin/components/charts/WishlistLeaderboard.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";

export default function WishlistLeaderboard() {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi("/api/analytics/products/most-wishlisted?limit=8", false);
      if (res?.success) {
        setData(res.data);
      }
    })();
  }, []);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Most Wishlisted</h3>
      <ul>
        {data.map((r, i) => (
          <li key={i} className="flex items-center gap-3 py-2 border-b last:border-b-0">
            <img src={r.product?.images?.[0] || "/images/logo.png"} width={48} height={48} alt="" />
            <div>
              <div className="font-medium">{r.product?.name || "Unknown"}</div>
              <div className="text-sm text-gray-500">Count: {r.count}</div>
            </div>
            <div className="ml-auto font-bold">{r.count}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
