// admin/components/charts/SearchIntentClusters.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";

export default function SearchIntentClusters({ start, end }) {
  const [clusters, setClusters] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const load = async () => {
      const q = `/api/analytics/search/intents?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}&limitClusters=50&minSize=2`;
      const res = await fetchDataFromApi(q, false);
      if (res?.success) setClusters(res.data || []);
    };
    if (start && end) load();
  }, [start, end]);

  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold">Search Intent Clusters</h3>
        <div className="text-sm text-gray-500">click cluster to view sample queries</div>
      </div>

      <div className="flex gap-2 overflow-x-auto py-2">
        {clusters.map((c, i) => (
          <button
            key={i}
            onClick={() => setSelected(c)}
            className="flex-shrink-0 px-4 py-2 bg-gray-100 rounded hover:bg-gray-200"
          >
            <div className="text-sm font-medium">{c.signature || "misc"}</div>
            <div className="text-xs text-gray-500">{c.total} searches</div>
          </button>
        ))}
      </div>

      <div className="mt-3">
        {selected ? (
          <div>
            <h4 className="font-medium">Sample queries in cluster ({selected.total})</h4>
            <ul className="mt-2 space-y-1 max-h-48 overflow-y-auto">
              {selected.queries.map((q, idx) => (
                <li key={idx} className="text-sm p-1 border-b">{q.query} <span className="text-gray-500">({q.count})</span></li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="text-sm text-gray-500">Select a cluster to see sample queries</div>
        )}
      </div>
    </div>
  );
}
