// admin/components/charts/ZeroResultSearches.jsx
"use client";
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function ZeroResultSearches({ start, end, unit = "day" }) {
  const [series, setSeries] = useState([]);
  const [topZero, setTopZero] = useState([]);

  useEffect(() => {
    const load = async () => {
      const q = `/api/analytics/search/zero-results?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}&unit=${unit}`;
      const res = await fetchDataFromApi(q, false);
      if (res?.success) {
        // map timeseries
        setSeries(res.timeseries.map(t => ({ time: new Date(t.time).toLocaleString(), count: t.count })));
        setTopZero(res.topZero || []);
      }
    };
    if (start && end) load();
  }, [start, end, unit]);

  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-semibold">Zero-Result Searches</h3>
        <div className="text-sm text-gray-600">unit: {unit}</div>
      </div>

      <div className="w-full h-44">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={series}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" tickFormatter={(t) => new Date(t).toLocaleString()} />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Line type="monotone" dataKey="count" stroke="#ef4444" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3">
        <h4 className="font-medium mb-2">Top zero-result queries</h4>
        <div className="flex flex-col gap-1 max-h-36 overflow-y-auto">
          {topZero.map((k, idx) => (
            <div key={idx} className="flex justify-between text-sm p-2 rounded hover:bg-gray-50">
              <div className="truncate pr-2">{k._id}</div>
              <div className="text-gray-500">({k.count})</div>
            </div>
          ))}
          {topZero.length === 0 && <div className="text-sm text-gray-500">No zero result searches in range</div>}
        </div>
      </div>
    </div>
  );
}
