// admin/components/charts/NewSignupsChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function NewSignupsChart({ type = "1day" }) {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/users/new-signups?type=${type}`, false);
      if (res?.success) setData(res.data.map((r) => ({ time: new Date(r.time).toLocaleString(), count: r.count })));
    })();
  }, [type]);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">New Signups</h3>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Area dataKey="count" stroke="#7c3aed" fill="#7c3aed" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
