"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";
import UserPageAnalyticsPanel from "./UserPageAnalyticsPanel";

export default function TopUsersTimeChart() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null); // visitorId
  const [panelOpen, setPanelOpen] = useState(false);

  const loadUsers = async () => {
    const res = await fetchDataFromApi("/api/analytics/timeSpent/topUsers", false);
    if (res?.success) {
      setUsers(res.data);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow relative">
      <h3 className="font-semibold text-black mb-4">Top Users (Time Spent)</h3>

      <table className="w-full text-sm text-left border-collapse">
        <thead>
          <tr className="bg-gray-100 text-black">
            <th className="p-2">User</th>
            <th className="p-2">Total Time</th>
            <th className="p-2">Sessions</th>
          </tr>
        </thead>

        <tbody>
          {users.map((user, i) => (
            <tr
              key={i}
              onClick={() => {
                setSelectedUser(user.visitorId);
                setPanelOpen(true);
              }}
              className="cursor-pointer hover:bg-gray-50 border-b"
            >
              <td className="p-2">
                <span className="font-medium text-blue-600">
                  {user.name || "Guest User"}
                </span>
                <br />
                <span className="text-gray-500 text-xs">{user.email || "No email"}</span>
              </td>

              <td className="p-2 font-semibold">{user.totalTime}s</td>
              <td className="p-2">{user.sessions}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Sliding Panel */}
      <UserPageAnalyticsPanel
        open={panelOpen}
        visitorId={selectedUser}
        onClose={() => setPanelOpen(false)}
      />
    </div>
  );
}
