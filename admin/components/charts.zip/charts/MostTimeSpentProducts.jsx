"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function MostTimeSpentProducts() {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    const res = await fetchDataFromApi(`/api/analytics/timeSpent/products?limit=10`, false);
    if (res?.success) {
      setData(
        res.data.map((p) => ({
          name: p.name,
          time: p.totalTime, // seconds
        }))
      );
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold text-black mb-3">Most Time Spent on Products</h3>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-20} />
          <YAxis allowDecimals={false} />
          <Tooltip />
          <Bar dataKey="time" fill="#6366f1" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
