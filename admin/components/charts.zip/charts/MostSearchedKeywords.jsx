"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip
} from "recharts";

export default function MostSearchedKeywords() {
  const [keywords, setKeywords] = useState([]);
  const [top10, setTop10] = useState([]);

  const loadKeywords = async () => {
    const res = await fetchDataFromApi("/api/analytics/search/most", false);
    if (res?.success) {
      setKeywords(res.data);
      setTop10(res.data.slice(0, 10)); // For the chart
    }
  };

  useEffect(() => {
    loadKeywords();
  }, []);

  return (
    <div className="bg-white p-4 rounded shadow mt-4">
      <h3 className="text-lg font-semibold text-black mb-3">
        🔍 Most Searched Keywords
      </h3>

      {/* Horizontal Scroll List */}
      <div
        className="flex gap-3 overflow-x-auto py-2"
        style={{ scrollbarWidth: "thin" }}
      >
        {keywords.map((k, index) => (
          <div
            key={index}
            className="flex-shrink-0 bg-blue-100 text-blue-700 px-4 py-2 rounded-full shadow hover:bg-blue-200 cursor-pointer"
          >
            <span className="font-medium">{k.keyword}</span>
            <span className="text-xs ml-2 text-gray-600">
              ({k.count})
            </span>
          </div>
        ))}
      </div>

      {/* Chart Title */}
      <h4 className="text-black font-medium mt-5 mb-2">Top 10 Keywords</h4>

      {/* Bar Chart */}
      <div className="w-full h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={top10}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="keyword" tick={{ fontSize: 10 }} interval={0} />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
