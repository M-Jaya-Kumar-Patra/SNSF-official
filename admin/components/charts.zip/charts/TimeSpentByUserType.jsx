"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function TimeSpentByUserType() {
  const [data, setData] = useState([]);
  const [total, setTotal] = useState(0);

  const fetchData = async () => {
    const res = await fetchDataFromApi(`/api/analytics/timeSpent/userType`, false);

    console.log("::::::::::::::::::::::::::::::::::", res)
    if (res?.success) {
      const arr = res.data.map((x) => ({
        type: x.userType,
        time: x.totalTime
      }));
      setData(arr);
      setTotal(arr.reduce((s, x) => s + x.time, 0));
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow">
      <div className="flex justify-between mb-2">
        <h3 className="font-semibold text-black">Time Spent by User Type</h3>
        <div className="font-bold">{total} sec</div>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="type" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="time" fill="#10b981" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
