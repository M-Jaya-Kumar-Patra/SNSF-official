"use client";
import React, { useState } from "react";

import UniqueVisitorsChart from "./UniqueVisitorsChart";
import NewVsReturningChart from "./NewVsReturningChart";
import DevicePieChart from "./DevicePieChart";
import BrowserPieChart from "./BrowserPieChart";
import CountryBarChart from "./CountryBarChart";
import AvgSessionDurationChart from "./AvgSessionDurationChart";
import BounceRateCard from "./BounceRateCard";
import PagesPerSessionChart from "./PagesPerSessionChart";
import MostViewedPagesChart from "./MostViewedPagesChart";
import ProductFunnelChart from "./ProductFunnelChart";
import MostViewedProductsChart from "./MostViewedProductsChart";
import WishlistLeaderboard from "./WishlistLeaderboard";
import DailyLoginsChart from "./DailyLoginsChart";
import NewSignupsChart from "./NewSignupsChart";
import MostTimeSpentPages from "./MostTimeSpentPages";
import TimeSpentByUserType from "./TimeSpentByUserType";
import MostTimeSpentProducts from "./MostTimeSpentProducts";
import TimeSpentByDevice from "./TimeSpentByDevice";
import ScrollDepthChart from "./ScrollDepthChart";
import TopUsersTimeChart from "./TopUsersTimeChart";
import MostSearchedKeywords from "./MostSearchedKeywords";
import ZeroResultSearches from "./ZeroResultSearches";
import TopSearchedCategories from "./TopSearchedCategories";
import SearchConversionFunnel from "./SearchConversionFunnel";
import SearchIntentClusters from "./SearchIntentClusters";
import ActiveUsersWidget from "./ActiveUsersWidget";
import LiveTopPages from "./LiveTopPages";
import LiveUserTable from "./LiveUserTable";
import LoginActivityChart from "./LoginActivityChart";

const tabs = [
  { id: "live", label: "Live" },
  { id: "visitor", label: "Visitors" },
  { id: "session", label: "Sessions" },
  { id: "pages", label: "Pages" },
  { id: "product", label: "Products" },
  { id: "search", label: "Search" },
  { id: "users", label: "Users" },
];

const Card = ({ children }) => (
  <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200">
    {children}
  </div>
);

export default function AnalyticsDashboard() {
  const [active, setActive] = useState("visitor");

  const now = new Date();
  const prior = new Date();
  prior.setDate(prior.getDate() - 7);

  return (
    <div className="bg-slate-50 rounded-xl p-6">

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setActive(t.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition
              ${
                active === t.id
                  ? "bg-slate-900 text-white"
                  : "bg-white border text-slate-600 hover:bg-slate-100"
              }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* VISITOR */}
      {active === "visitor" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Visitor Overview
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            <Card><LoginActivityChart /></Card>
            <Card><UniqueVisitorsChart /></Card>
            <Card><NewVsReturningChart /></Card>
            <Card><DevicePieChart /></Card>
            <Card><BrowserPieChart /></Card>
            <Card><CountryBarChart /></Card>
            <Card><TimeSpentByDevice /></Card>
            <Card><ScrollDepthChart /></Card>
          </div>
        </>
      )}

      {/* SESSION */}
      {active === "session" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Session Quality
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><AvgSessionDurationChart /></Card>
            <Card><BounceRateCard /></Card>
            <Card><PagesPerSessionChart /></Card>
          </div>
        </>
      )}

      {/* PAGES */}
      {active === "pages" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Page Engagement
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><MostViewedPagesChart /></Card>
            <Card><MostTimeSpentPages /></Card>
            <Card><TimeSpentByUserType /></Card>
          </div>
        </>
      )}

      {/* PRODUCT */}
      {active === "product" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Product Performance
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><ProductFunnelChart /></Card>
            <Card><MostViewedProductsChart /></Card>
            <Card><WishlistLeaderboard /></Card>
            <Card><MostTimeSpentProducts /></Card>
          </div>
        </>
      )}

      {/* SEARCH */}
      {active === "search" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Search Analytics
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><MostSearchedKeywords /></Card>
            <Card><ZeroResultSearches start={prior} end={now} /></Card>
            <Card><TopSearchedCategories start={prior} end={now} /></Card>
            <Card><SearchConversionFunnel start={prior} end={now} /></Card>
            <Card><SearchIntentClusters start={prior} end={now} /></Card>
          </div>
        </>
      )}

      {/* USERS */}
      {active === "users" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            User Growth
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><DailyLoginsChart /></Card>
            <Card><NewSignupsChart /></Card>
            <Card><TopUsersTimeChart /></Card>
          </div>
        </>
      )}

      {/* LIVE */}
      {active === "live" && (
        <>
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            Live Activity
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><ActiveUsersWidget /></Card>
            <Card><DevicePieChart /></Card>
            <Card className="md:col-span-2"><LiveTopPages /></Card>
            <Card className="md:col-span-2"><LiveUserTable /></Card>
          </div>
        </>
      )}
    </div>
  );
}
