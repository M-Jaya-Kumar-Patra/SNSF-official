// admin/components/charts/MostViewedProductsChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export default function MostViewedProductsChart() {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi("/api/analytics/products/most-viewed?limit=8", false);
      if (res?.success) {
        setData(res.data.map((r) => ({ name: r.product?.name || "Unknown", views: r.views })));
      }
    })();
  }, []);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Most Viewed Products</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" width={220} />
          <Tooltip />
          <Bar dataKey="views" fill="#2563eb" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
