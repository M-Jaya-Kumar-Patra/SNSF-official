"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function ScrollDepthChart() {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    const res = await fetchDataFromApi("/api/analytics/scrollDepth/top", false);
    if (res?.success) {
      setData(
        res.data.map((x) => ({
          page: x.page,
          depth: x.avgScroll
        }))
      );
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold text-black mb-3">Top Pages by Scroll Depth</h3>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="page" tick={{ fontSize: 12 }} />
          <YAxis />
          <Tooltip />
          <Bar dataKey="depth" fill="#f59e0b" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
