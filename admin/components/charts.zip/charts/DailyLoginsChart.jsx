// admin/components/charts/DailyLoginsChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function DailyLoginsChart({ type = "1day" }) {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/users/daily-logins?type=${type}`, false);
      if (res?.success) setData(res.data.map((r) => ({ time: new Date(r.time).toLocaleString(), count: r.count })));
    })();
  }, [type]);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Daily Logins</h3>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Area dataKey="count" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
