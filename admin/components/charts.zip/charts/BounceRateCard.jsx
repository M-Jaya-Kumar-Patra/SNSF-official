// admin/components/charts/BounceRateCard.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";

export default function BounceRateCard({ type = "1day" }) {
  const [data, setData] = useState({ total: 0, bounces: 0, bounceRate: 0 });
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/sessions/bounce-rate?type=${type}`, false);
      if (res?.success) setData(res.data);
    })();
  }, [type]);
  return (
    <div className="p-4 bg-white rounded shadow flex flex-col justify-center items-start">
      <h3 className="font-semibold">Bounce Rate</h3>
      <div className="text-3xl font-bold mt-2">{data.bounceRate ?? 0}%</div>
      <div className="text-sm text-gray-500 mt-1">Sessions: {data.total} | Bounces: {data.bounces}</div>
    </div>
  );
}
