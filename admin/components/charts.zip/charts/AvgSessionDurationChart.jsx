// admin/components/charts/AvgSessionDurationChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function AvgSessionDurationChart({ type = "1day" }) {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/sessions/avg-duration?type=${type}`, false);
      if (res?.success) {
        setData(res.data.map((r) => ({ time: new Date(r.time).toLocaleString(), avgSeconds: Math.round(r.avgSeconds) })));
      }
    })();
  }, [type]);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Avg Session Duration (s)</h3>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3"/>
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Area dataKey="avgSeconds" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
