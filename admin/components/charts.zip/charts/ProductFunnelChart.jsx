// admin/components/charts/ProductFunnelChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { fetchDataFromApi } from "@/utils/api";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export default function ProductFunnelChart({ productId }) {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const url = productId ? `/api/analytics/funnel/product?productId=${productId}` : `/api/analytics/funnel/product`;
      const res = await fetchDataFromApi(url, false);
      if (res?.success) {
        const d = [
          { step: "Views", count: res.data.views || 0 },
          { step: "AddToCart", count: res.data.addToCart || 0 },
          { step: "RemoveFromCart", count: res.data.removeFromCart || 0 },
        ];
        setData(d);
      }
    })();
  }, [productId]);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Product Funnel</h3>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="step" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="count" fill="#ef4444" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
