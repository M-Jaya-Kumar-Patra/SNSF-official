// admin/components/charts/PagesPerSessionChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function PagesPerSessionChart({ type = "1day" }) {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/sessions/pages-per-session?type=${type}`, false);
      if (res?.success) {
        setData(res.data.map((r) => ({ pages: r._id, sessions: r.count })));
      }
    })();
  }, [type]);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Pages Per Session</h3>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="pages" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="sessions" fill="#10b981" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
