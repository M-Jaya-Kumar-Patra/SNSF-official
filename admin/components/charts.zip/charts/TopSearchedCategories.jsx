// admin/components/charts/TopSearchedCategories.jsx
"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function TopSearchedCategories({ start, end, limit = 10 }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    const load = async () => {
      const q = `/api/analytics/search/top-categories?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}&limit=${limit}`;
      const res = await fetchDataFromApi(q, false);
      if (res?.success) setData(res.data || []);
    };
    if (start && end) load();
  }, [start, end, limit]);

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-3">Top Searched Categories</h3>
      <div className="w-full h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart layout="vertical" data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" allowDecimals={false} />
            <YAxis dataKey="cat" type="category" width={180} />
            <Tooltip />
            <Bar dataKey="count" fill="#10b981" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
