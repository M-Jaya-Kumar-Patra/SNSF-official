// admin/components/charts/MostViewedPagesChart.jsx
"use client";
import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fetchDataFromApi } from "@/utils/api";

export default function MostViewedPagesChart() {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetchDataFromApi(`/api/analytics/pages/most-viewed?limit=8`, false);
      if (res?.success) {
        setData(res.data.map((r) => ({ page: r._id, views: r.views })));
      }
    })();
  }, []);
  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="font-semibold mb-2">Most Viewed Pages</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart layout="vertical" data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis dataKey="page" type="category" width={200} />
          <Tooltip />
          <Bar dataKey="views" fill="#7c3aed" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
